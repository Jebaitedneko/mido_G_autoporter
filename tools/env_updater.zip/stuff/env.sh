#!/sbin/sh
ln -s /dev/block/bootdevice/by-name/vendor /dev/block/bootdevice/by-name/cust
