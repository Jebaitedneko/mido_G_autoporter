#!/sbin/sh
sed -i 's/\/cust/\/vendor/g' /vendor/etc/fstab.qcom
cat /tmp/stuff/init.qcom.rc >> /vendor/etc/init/hw/init.qcom.rc
cat /tmp/stuff/init.target.rc >> /vendor/etc/init/hw/init.target.rc
