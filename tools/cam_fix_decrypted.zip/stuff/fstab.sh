#!/sbin/sh
sed -i 's/,encryptable=[a-z]*[,]/\,/g' /vendor/etc/fstab.qcom
sed -i 's/,encryptable=[a-z]*//g' /vendor/etc/fstab.qcom
awk 'BEGIN{RS="";ORS="\n"}1' /vendor/etc/fstab.qcom > /vendor/etc/fstab.qcom.new
rm /vendor/etc/fstab.qcom
mv /vendor/etc/fstab.qcom.new /vendor/etc/fstab.qcom
