#!/sbin/sh
sed -i '/^#/d' /vendor/etc/fstab.qcom
sed -i 's/\/cust/\/vendor/g' /vendor/etc/fstab.qcom
awk 'BEGIN{RS="";ORS="\n"}1' /vendor/etc/fstab.qcom > /vendor/etc/fstab.qcom.new
rm /vendor/etc/fstab.qcom
mv /vendor/etc/fstab.qcom.new /vendor/etc/fstab.qcom
cat /tmp/stuff/init.qcom.rc >> /vendor/etc/init/hw/init.qcom.rc
cat /tmp/stuff/init.target.rc >> /vendor/etc/init/hw/init.target.rc
